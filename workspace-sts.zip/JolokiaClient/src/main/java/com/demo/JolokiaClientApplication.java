package com.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.jolokia.client.J4pClient;
import org.jolokia.client.request.J4pReadRequest;
import org.jolokia.client.request.J4pReadResponse;

import java.util.Map;


@SpringBootApplication
public class JolokiaClientApplication {

	public static void main(String[] args) throws Exception {
		SpringApplication.run(JolokiaClientApplication.class, args);
		ff();
	}

	


	/**
	 * Created by jtpark on 2017-08-11.
	 */
	    public static void ff() throws Exception {
	        J4pClient j4pClient = new J4pClient("http://localhost:8181/actuator/jolokia");

	        J4pReadRequest req = new J4pReadRequest("java.lang:type=Memory", "HeapMemoryUsage");
	        J4pReadResponse resp = j4pClient.execute(req);
	        Map<String, Long> vals = resp.getValue();
	        long used = vals.get("used");
	        long max = vals.get("max");
	        int usage = (int) (used * 100 / max);
	        System.out.println("Memory usage: used: " + used + " / max: " + max + " = " + usage + "%");

//
//	        J4pClient j4pClient2 = new J4pClient("http://10.101.101.208:8161/jolokia/");
//
//	        J4pReadRequest req2 = new J4pReadRequest("org.apache.activemq.artemis:broker=\"0.0.0.0\"", "Version");
//	        J4pReadResponse resp2 = j4pClient2.execute(req2);
//	        String version = resp2.getValue();
//	        System.out.println("ActiveMQ Artemis version: " + version);

	    }
}
