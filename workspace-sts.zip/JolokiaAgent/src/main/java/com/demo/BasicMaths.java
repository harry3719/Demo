package com.demo;

import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedResource;

@ManagedResource
public class BasicMaths implements BasicMathsMbean {

    @ManagedOperation
    @Override
    public Float add(Float a, Float b) {
        return a+b;
    }

    @ManagedOperation
    @Override
    public Float subtract(Float a, Float b) {
        return a-b;
    }

}