package com.demo;

public interface BasicMathsMbean {

    Float add(Float a, Float b);

    Float subtract(Float a, Float b);

}