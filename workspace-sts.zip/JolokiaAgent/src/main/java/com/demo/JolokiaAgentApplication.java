package com.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class JolokiaAgentApplication {

	public static void main(String[] args) {
		SpringApplication.run(JolokiaAgentApplication.class, args);
	}

	@Bean
	public BasicMathsMbean basicMathsMbean(){
	    return new BasicMaths();
	}
}
